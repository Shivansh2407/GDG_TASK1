# AgriTech
#PlatForm to Help The Farmers#
*This Web Portal*
